import { Resend } from 'resend';
const resend = () => {
  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM) throw new Error('Email delivery is not configured');
  return new Resend(process.env.RESEND_API_KEY);
};
export async function sendEmail(to: string, subject: string, html: string) {
  const result = await resend().emails.send({ from: process.env.EMAIL_FROM!, to, subject, html });
  if (result.error) throw new Error('Email delivery failed');
}
export const esc = (s: string) => s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
