import { google } from 'googleapis';
import crypto from 'node:crypto';
import { db } from './db';

export function oauthClient() {
  const { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI } = process.env;
  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET || !GOOGLE_REDIRECT_URI) throw new Error('Google OAuth is not configured');
  return new google.auth.OAuth2(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI);
}
function encryptionKey() {
  const raw = process.env.TOKEN_ENCRYPTION_KEY;
  if (!raw) throw new Error('TOKEN_ENCRYPTION_KEY is not configured');
  const key = Buffer.from(raw, 'base64');
  if (key.length !== 32) throw new Error('TOKEN_ENCRYPTION_KEY must decode to 32 bytes');
  return key;
}
function encrypt(value: string) {
  const iv = crypto.randomBytes(12); const cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey(), iv);
  const data = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  return [iv.toString('base64url'), cipher.getAuthTag().toString('base64url'), data.toString('base64url')].join('.');
}
function decrypt(value: string) {
  const [iv, tag, data] = value.split('.'); const decipher = crypto.createDecipheriv('aes-256-gcm', encryptionKey(), Buffer.from(iv, 'base64url'));
  decipher.setAuthTag(Buffer.from(tag, 'base64url'));
  return Buffer.concat([decipher.update(Buffer.from(data, 'base64url')), decipher.final()]).toString('utf8');
}
export async function saveGoogleTokens(tokens: Record<string, unknown>) {
  for (const [key, value] of Object.entries(tokens)) {
    if (value === undefined || value === null) continue;
    await db.appSetting.upsert({ where: { key: `google:${key}` }, create: { key: `google:${key}`, value: encrypt(String(value)) }, update: { value: encrypt(String(value)) } });
  }
}
export async function getCalendarClient() {
  const rows = await db.appSetting.findMany({ where: { key: { startsWith: 'google:' } } });
  if (!rows.some(r => r.key === 'google:refresh_token')) throw new Error('Google Calendar is not connected. Connect it before approving requests.');
  const tokens: Record<string, string> = {};
  for (const row of rows) tokens[row.key.slice(7)] = decrypt(row.value);
  const auth = oauthClient(); auth.setCredentials(tokens);
  auth.on('tokens', async updated => { await saveGoogleTokens(updated as Record<string, unknown>); });
  return google.calendar({ version: 'v3', auth });
}
