import crypto from 'node:crypto';

export function randomToken() { return crypto.randomBytes(32).toString('base64url'); }
export function tokenHash(token: string) { return crypto.createHash('sha256').update(token).digest('hex'); }
export function safeEqual(a: string, b: string) {
  const aa = Buffer.from(a); const bb = Buffer.from(b);
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
export function appUrl(path: string) {
  const base = process.env.APP_URL;
  if (!base) throw new Error('APP_URL is not configured');
  return new URL(path, base).toString();
}
export async function verifyTurnstile(token: unknown, ip?: string) {
  if (process.env.NODE_ENV !== 'production' && !process.env.TURNSTILE_SECRET_KEY) return true;
  if (typeof token !== 'string' || !process.env.TURNSTILE_SECRET_KEY) return false;
  const body = new URLSearchParams({ secret: process.env.TURNSTILE_SECRET_KEY, response: token });
  if (ip) body.set('remoteip', ip);
  const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body, cache: 'no-store' });
  if (!response.ok) return false;
  const result = await response.json() as { success?: boolean };
  return result.success === true;
}
export async function checkRateLimit(key: string, max = 5, windowMs = 60 * 60 * 1000) {
  const { db } = await import('./db');
  const now = new Date();
  const existing = await db.rateLimit.findUnique({ where: { key } });
  if (!existing || now.getTime() - existing.windowAt.getTime() >= windowMs) {
    await db.rateLimit.upsert({ where: { key }, create: { key, count: 1, windowAt: now }, update: { count: 1, windowAt: now } });
    return true;
  }
  if (existing.count >= max) return false;
  await db.rateLimit.update({ where: { key }, data: { count: { increment: 1 } } });
  return true;
}
export function clientIp(request: Request) {
  // Only trust this header when your hosting platform overwrites it; otherwise use a platform-specific trusted IP source.
  return request.headers.get('x-real-ip') || request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
}
