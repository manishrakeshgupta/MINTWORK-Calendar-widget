# Calendar Approval Booking App — starter

A Next.js starter for an embedded appointment request widget with email verification, bot protection hooks, manual approval by secure email links, and Google Calendar event creation **only after a deliberate approval POST**.

## Important status

This is a starter scaffold, not a production-ready deployment. Google OAuth setup routes are deliberately disabled in production until owner-only authentication is added. The frontend shows the Turnstile configuration notice but the actual Cloudflare client widget still needs to be added; production requests fail closed unless valid Turnstile tokens are verified. The public booking page is usable for local development with email delivery configured.

## Requirements

- Node.js 20+
- Google Cloud project with Calendar API enabled and OAuth 2.0 Web client credentials
- Resend account and verified sending domain
- Cloudflare Turnstile site + secret keys
- A production database (change Prisma datasource from SQLite to PostgreSQL before deploying)
- Owner-only admin authentication before enabling production OAuth and decision endpoints

## Local setup

1. Copy `.env.example` to `.env` and fill in values.
2. Generate `APP_SECRET` with `openssl rand -base64 48`.
3. Generate `TOKEN_ENCRYPTION_KEY` with `openssl rand -base64 32`.
4. Install dependencies: `npm install`.
5. Generate Prisma client and initialize local database: `npm run db:generate && npm run db:push`.
6. Start: `npm run dev`.
7. Configure Google OAuth redirect URI to `http://localhost:3000/api/google/callback`.
8. For local-only OAuth setup, visit `/api/google/connect`. This route is intentionally blocked in production until authentication is implemented.

## Request flow

1. Visitor submits name, email, purpose, requested date/time and timezone.
2. Server validates fields, rate limits by IP/email, checks the honeypot and validates Turnstile server-side.
3. A one-time email verification token is stored only as a SHA-256 hash and expires after 30 minutes.
4. Visitor verifies their email. The request becomes `PENDING_APPROVAL`; no calendar event is created.
5. The owner receives one-time approval/rejection links. GET only displays a confirmation page; it does not mutate state.
6. The owner confirms via POST. Approval claims the request, rechecks Google Calendar free/busy, and only then creates an event.
7. Rejecting a request never calls the Calendar API.

## Production hardening required before public launch

- Add real owner authentication (e.g. Auth.js with an allowlisted owner account) to the approval endpoints, OAuth connect/callback setup, and any admin page. Email links are bearer secrets; keep them private and use HTTPS.
- Implement the Turnstile client widget in `components/BookingWidget.tsx` and submit its token as `turnstileToken`. Configure real keys; the server fails closed when no secret is configured in production.
- Change Prisma to PostgreSQL for hosted multi-instance deployment. Add atomic rate limiting backed by Redis or a database transaction; the included simple limiter is only a starter.
- Add CSRF/origin protection to POST endpoints, audit logs, monitoring, and a recovery workflow for `PROCESSING` records after transient Google API errors.
- Configure correct trusted client IP handling for your hosting provider; do not blindly trust spoofable forwarded headers.
- Add an owner-facing calendar connection status and rotate/revoke credentials if compromised.
- Test OAuth token refresh, email delivery failures, race conditions, daylight-saving transitions, double-booking conflicts, and duplicate clicks before production.
- Set privacy notice/retention policy. Avoid collecting more personal information than needed.

## Embed on another website

Deploy this app to a stable HTTPS domain, then embed it with an iframe:

```html
<iframe
  src="https://YOUR-BOOKING-DOMAIN.example/"
  title="Request an appointment"
  width="100%"
  height="900"
  loading="lazy"
  style="border:0;border-radius:16px;max-width:760px"
></iframe>
```

For production, configure a restrictive `frame-ancestors` CSP for the site(s) that are allowed to embed the widget. Do not allow arbitrary origins.

## Event policy

The public request endpoint and email-verification endpoint cannot create calendar events. The only `calendar.events.insert` call is in `app/api/admin/decision/route.ts` and is reached only after a valid one-time approval token is submitted with `action=approve` and the request has been claimed. A conflict is rejected rather than booked.
