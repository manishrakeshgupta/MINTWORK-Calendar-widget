import BookingWidget from '@/components/BookingWidget';
export default function Home() {
  return <main className="shell"><div className="panel"><div className="eyebrow">Appointment request</div><h1 style={{fontSize:32,letterSpacing:'-.04em',marginBottom:8}}>Let's find a time to talk.</h1><p className="muted">Send an appointment request below. To protect my calendar, every request is reviewed manually. Your meeting is not booked until you receive an approval email.</p><BookingWidget /></div><p className="muted" style={{textAlign:'center',marginTop:18}}>Secure request form · No appointment is created automatically</p></main>;
}
