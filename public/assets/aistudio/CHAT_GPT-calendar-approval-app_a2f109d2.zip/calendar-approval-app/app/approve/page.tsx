import { redirect } from 'next/navigation';
import { appUrl, tokenHash } from '@/lib/security';
import { db } from '@/lib/db';
export const dynamic='force-dynamic';
export default async function ApprovePage({searchParams}:{searchParams:Promise<{token?:string;action?:string}>}){
 const p=await searchParams;if(!p.token||!['approve','reject'].includes(p.action||''))redirect(appUrl('/'));
 const booking=await db.bookingRequest.findUnique({where:{approvalHash:tokenHash(p.token)}});
 if(!booking||booking.status!=='PENDING_APPROVAL'||!booking.approvalExpires||booking.approvalExpires<new Date())return <main className="shell"><div className="panel"><h1>Link unavailable</h1><p className="muted">This link is invalid, expired or already used. No calendar event was created by opening this page.</p></div></main>;
 return <main className="shell"><div className="panel"><div className="eyebrow">Private approval</div><h1>{p.action==='approve'?'Approve this request?':'Reject this request?'}</h1><p><b>{booking.name}</b> · {booking.email}</p><p>{booking.purpose}</p><p className="muted">Requested time: {booking.requestedStart.toISOString()} ({booking.timezone}). Confirming approval will create the Google Calendar event. Availability is checked again first.</p><form method="post" action="/api/admin/decision"><input type="hidden" name="token" value={p.token}/><input type="hidden" name="action" value={p.action}/><button className="btn" type="submit">Confirm {p.action}</button></form><p className="muted">This page is a review step. Merely opening the email link has no effect.</p></div></main>;
}
