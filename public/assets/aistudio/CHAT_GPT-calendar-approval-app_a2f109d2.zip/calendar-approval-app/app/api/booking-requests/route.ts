import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { appUrl, checkRateLimit, clientIp, randomToken, tokenHash, verifyTurnstile } from '@/lib/security';
import { esc, sendEmail } from '@/lib/email';

const schema=z.object({name:z.string().trim().min(1).max(100),email:z.string().trim().email().max(254),company:z.string().trim().max(120).optional().default(''),purpose:z.string().trim().min(3).max(1200),date:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),time:z.string().regex(/^\d{2}:\d{2}$/),timezone:z.string().max(80),website:z.string().max(0).optional().default(''),turnstileToken:z.string().optional().default('')});
export async function POST(request:Request){
 try{
  const raw=await request.json(); const parsed=schema.safeParse(raw); if(!parsed.success)return NextResponse.json({error:'Please check the form fields and try again.'},{status:400});
  const v=parsed.data; if(v.website)return NextResponse.json({error:'Request rejected.'},{status:400});
  const ip=clientIp(request); if(!await checkRateLimit(`ip:${ip}`,8)||!await checkRateLimit(`email:${v.email.toLowerCase()}`,3))return NextResponse.json({error:'Too many requests. Please try again later.'},{status:429});
  if(!await verifyTurnstile(v.turnstileToken,ip))return NextResponse.json({error:'Bot verification failed. Refresh and try again.'},{status:400});
  let start:Date; try{const {Temporal}=await import('@js-temporal/polyfill'); const zdt=Temporal.ZonedDateTime.from(`${v.date}T${v.time}:00[${v.timezone}]`); start=new Date(Number(zdt.epochMilliseconds));}catch{return NextResponse.json({error:'Invalid date, time or time zone.'},{status:400});}
  if(start.getTime()<Date.now()+60*60*1000)return NextResponse.json({error:'Please choose a time at least one hour from now.'},{status:400});
  const end=new Date(start.getTime()+30*60*1000); const token=randomToken();
  const booking=await db.bookingRequest.create({data:{name:v.name,email:v.email.toLowerCase(),company:v.company||null,purpose:v.purpose,requestedStart:start,requestedEnd:end,timezone:v.timezone,verificationHash:tokenHash(token),verificationExpires:new Date(Date.now()+30*60*1000)}});
  const link=appUrl(`/api/verify-email?token=${encodeURIComponent(token)}`);
  await sendEmail(booking.email,'Verify your appointment request',`<p>Hi ${esc(booking.name)},</p><p>Please verify your email to submit your appointment request.</p><p><a href="${link}">Verify email and submit request</a></p><p>This does not book an appointment. The meeting will only be added to the calendar after manual approval.</p><p>This link expires in 30 minutes.</p>`);
  return NextResponse.json({ok:true,message:'Verification email sent.'},{status:202});
 }catch(error){console.error('booking request failed',error);return NextResponse.json({error:'We could not process this request right now. Please try again later.'},{status:500});}
}
