import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { appUrl, randomToken, tokenHash } from '@/lib/security';
import { esc, sendEmail } from '@/lib/email';
export async function GET(request:Request){
 const url=new URL(request.url);const token=url.searchParams.get('token');if(!token)return NextResponse.redirect(appUrl('/?verified=invalid'));
 const booking=await db.bookingRequest.findUnique({where:{verificationHash:tokenHash(token)}});
 if(!booking||!booking.verificationExpires||booking.verificationExpires<new Date()||booking.status!=='PENDING_VERIFICATION')return NextResponse.redirect(appUrl('/?verified=expired'));
 const approval=randomToken();
 const updated=await db.bookingRequest.updateMany({where:{id:booking.id,status:'PENDING_VERIFICATION',verificationHash:tokenHash(token)},data:{status:'PENDING_APPROVAL',emailVerifiedAt:new Date(),verificationHash:null,verificationExpires:null,approvalHash:tokenHash(approval),approvalExpires:new Date(Date.now()+72*60*60*1000)}});
 if(updated.count!==1)return NextResponse.redirect(appUrl('/?verified=used'));
 const approve=appUrl(`/approve?token=${encodeURIComponent(approval)}&action=approve`);const reject=appUrl(`/approve?token=${encodeURIComponent(approval)}&action=reject`);
 try{await sendEmail(process.env.OWNER_EMAIL!,`Appointment request: ${booking.name}`,`<h2>New appointment request</h2><p><b>Name:</b> ${esc(booking.name)}</p><p><b>Email:</b> ${esc(booking.email)}</p><p><b>Company:</b> ${esc(booking.company||'—')}</p><p><b>Purpose:</b> ${esc(booking.purpose)}</p><p><b>Requested:</b> ${esc(booking.requestedStart.toISOString())} (${esc(booking.timezone)})</p><p>This request has been email-verified. No calendar event exists yet.</p><p><a href="${approve}">Review and approve</a></p><p><a href="${reject}">Reject request</a></p><p>Links expire in 72 hours and can be used once. Opening a link does not itself take action; you must confirm on the page.</p>`);}catch(error){console.error('owner notification failed',error);return NextResponse.redirect(appUrl('/?verified=notification-error'));}
 return NextResponse.redirect(appUrl('/?verified=sent'));
}
