import crypto from 'node:crypto';
import { NextResponse } from 'next/server';
import { oauthClient } from '@/lib/google';
import { appUrl } from '@/lib/security';
export async function GET(){
 // This starter intentionally restricts OAuth initiation to local development until admin authentication is configured.
 if(process.env.NODE_ENV==='production')return new NextResponse('Protect this route with owner-only authentication before production deployment.',{status:501});
 const state=crypto.randomBytes(24).toString('hex');const client=oauthClient();const url=client.generateAuthUrl({access_type:'offline',prompt:'consent',scope:['https://www.googleapis.com/auth/calendar.events','https://www.googleapis.com/auth/calendar.freebusy'],state});
 const response=NextResponse.redirect(url);response.cookies.set('google_oauth_state',state,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',path:'/',maxAge:600});return response;
}
