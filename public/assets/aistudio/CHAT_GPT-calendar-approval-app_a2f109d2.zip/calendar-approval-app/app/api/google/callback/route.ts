import { NextResponse } from 'next/server';
import { oauthClient, saveGoogleTokens } from '@/lib/google';
import { appUrl, safeEqual } from '@/lib/security';
export async function GET(request:Request){
 const url=new URL(request.url);const state=url.searchParams.get('state')||'';const code=url.searchParams.get('code');
 // OAuth callback is intentionally disabled in production until owner-only setup authentication is implemented.
 if(process.env.NODE_ENV==='production')return new NextResponse('Configure owner-only authentication before enabling Google OAuth in production.',{status:501});
 const cookie=request.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('google_oauth_state='))?.split('=').slice(1).join('=')||'';
 if(!state||!cookie||!safeEqual(state,cookie)||!code)return new NextResponse('Invalid OAuth state.',{status:400});
 try{const client=oauthClient();const {tokens}=await client.getToken(code);await saveGoogleTokens(tokens as Record<string,unknown>);const response=NextResponse.redirect(appUrl('/?google=connected'));response.cookies.delete('google_oauth_state');return response;}catch{return new NextResponse('Could not complete Google OAuth.',{status:500});}
}
