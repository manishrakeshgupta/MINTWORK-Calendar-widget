import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { appUrl, tokenHash } from '@/lib/security';
import { getCalendarClient } from '@/lib/google';
import { esc, sendEmail } from '@/lib/email';
export async function POST(request:Request){
 try{
  const form=await request.formData();const token=String(form.get('token')||'');const action=String(form.get('action')||'');if(!token||!['approve','reject'].includes(action))return NextResponse.redirect(appUrl('/?decision=invalid'));
  const booking=await db.bookingRequest.findUnique({where:{approvalHash:tokenHash(token)}});
  if(!booking||booking.status!=='PENDING_APPROVAL'||!booking.approvalExpires||booking.approvalExpires<new Date())return NextResponse.redirect(appUrl('/?decision=expired'));
  if(action==='reject'){
   const result=await db.bookingRequest.updateMany({where:{id:booking.id,status:'PENDING_APPROVAL',approvalHash:tokenHash(token)},data:{status:'REJECTED',decisionAt:new Date(),approvalHash:null,approvalExpires:null}});
   if(result.count!==1)return NextResponse.redirect(appUrl('/?decision=used'));
   await sendEmail(booking.email,'Appointment request update',`<p>Hi ${esc(booking.name)},</p><p>Thanks for your request. Unfortunately, I cannot accept this requested time.</p>`);
   return NextResponse.redirect(appUrl('/?decision=rejected'));
  }
  // Claim the request before touching Google. This prevents two clicks from creating two events.
  const claim=await db.bookingRequest.updateMany({where:{id:booking.id,status:'PENDING_APPROVAL',approvalHash:tokenHash(token)},data:{status:'PROCESSING',decisionAt:new Date()}});
  if(claim.count!==1)return NextResponse.redirect(appUrl('/?decision=used'));
  try{
   const calendar=await getCalendarClient();
   const free=await calendar.freebusy.query({requestBody:{timeMin:booking.requestedStart.toISOString(),timeMax:booking.requestedEnd.toISOString(),items:[{id:'primary'}]}});
   const busy=free.data.calendars?.primary?.busy||[];
   if(busy.length){await db.bookingRequest.update({where:{id:booking.id},data:{status:'CONFLICT',approvalHash:null,approvalExpires:null}});await sendEmail(booking.email,'Appointment request update',`<p>Hi ${esc(booking.name)},</p><p>That time is no longer available. Please submit another request.</p>`);return NextResponse.redirect(appUrl('/?decision=conflict'));}
   const event=await calendar.events.insert({calendarId:'primary',requestBody:{summary:`Meeting with ${booking.name}`,description:`Purpose: ${booking.purpose}\nCompany: ${booking.company||'—'}\nContact: ${booking.email}\nCreated after manual approval.`,start:{dateTime:booking.requestedStart.toISOString(),timeZone:booking.timezone},end:{dateTime:booking.requestedEnd.toISOString(),timeZone:booking.timezone},attendees:[{email:booking.email}]},sendUpdates:'all'});
   await db.bookingRequest.update({where:{id:booking.id},data:{status:'APPROVED',calendarEventId:event.data.id||null,approvalHash:null,approvalExpires:null}});
   await sendEmail(booking.email,'Your appointment is confirmed',`<p>Hi ${esc(booking.name)},</p><p>Your appointment has been approved and added to Google Calendar. Google Calendar will send the event invitation separately.</p>`);
   return NextResponse.redirect(appUrl('/?decision=approved'));
  }catch(error){console.error('approval/calendar failure',error);await db.bookingRequest.update({where:{id:booking.id},data:{status:'PENDING_APPROVAL',decisionAt:null}});return NextResponse.redirect(appUrl('/?decision=error'));}
 }catch(error){console.error('decision failed',error);return NextResponse.redirect(appUrl('/?decision=error'));}
}
