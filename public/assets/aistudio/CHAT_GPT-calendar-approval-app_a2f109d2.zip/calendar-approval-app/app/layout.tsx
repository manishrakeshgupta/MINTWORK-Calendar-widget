import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Request an appointment', description: 'Request a meeting. Every request is reviewed manually.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
